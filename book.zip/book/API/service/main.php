<?php
	/**
	 * 
	 */
	function send($to, $userName,$bookDate){
		date_default_timezone_set('Asia/Ho_Chi_Minh');
		$currentDate=date("Y/m/d h:i:sa");
		$txt = "Kính gửi:$userName \nHôm nay là ngày:\"$currentDate\".\n"
		."Với mục đích thông báo chúng tôi gửi mail xác nhận lịch hẹn đã đặt thành công này đến Ông/Bà.\n"
		."Mong Ông/Bà đến đúng ngày hẹn: \"$bookDate\".";
		$txt = wordwrap($txt,70);
		$headers = "From: vsnam95@gmail.com"."\r\n"."CC: $to";
		$subject="Đặt Lịch Hẹn";
		return 	mail($to,$subject,$txt,$headers);
	}
	function getAPI($key, $defualtValue=''){
		return isset($_GET[$key]) ? $_GET[$key] : $defualtValue;
	}
	function postAPI($key, $defualtValue=''){
		return isset($_POST[$key]) ? $_POST[$key] : $defualtValue;
	}
	// echo send('vosonnam95@gmail.com', 'Võ Sơn nam','2021-07-11 19:04');
?>