<?php
require_once("../server.php");
$event=$_POST['event'];
switch ($event) {
	case "getbooked":
	    $id=$_POST['id'];
	    //c81e728d9d4c2f636f067f89cc14862c
	    $sql=mysqli_query($conn,"SELECT `name`, `phone`, `date`, `time`, `bookdate`, `status` FROM `book` WHERE MD5(`id`)='$id' LIMIT 1");
	    $row=mysqli_fetch_array($sql); 
	    $usertemp=array();
        $usertemp['name']=$row['name'];
        $usertemp['phone']=$row['phone'];
        $usertemp['date']=$row['date'];
        $usertemp['time']=$row['time'];
        $usertemp['bookeddate']=$row['bookdate'];
        $usertemp['status']=$row['status'];
	    $jsonData[$event] =$usertemp;
	    echo json_encode($jsonData);
		break;
		
	default:
      # code...
      break;
}
mysqli_close($conn);
?>