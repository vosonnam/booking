-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th7 07, 2021 lúc 03:53 AM
-- Phiên bản máy phục vụ: 10.4.10-MariaDB
-- Phiên bản PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `booking`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` char(10) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `bookdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `fbemail` char(1) NOT NULL,
  `fbsms` char(1) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `book`
--

INSERT INTO `book` (`id`, `name`, `phone`, `date`, `time`, `bookdate`, `fbemail`, `fbsms`, `status`) VALUES
(6, 'Võ Sơn nam', '0933245772', '2021-07-29', '06:41', '2021-07-05 17:44:08', '0', '1', '1'),
(7, 'Võ Sơn nam', '0965276269', '2021-07-29', '12:41', '2021-07-05 17:44:12', '0', '1', '1'),
(8, 'Võ Sơn nam', '0398086729', '2021-07-06', '12:41', '2021-07-05 17:44:17', '0', '1', '1'),
(9, 'Võ Sơn nam', '0966302118', '2021-07-06', '18:41', '2021-07-05 17:44:22', '0', '1', '1'),
(10, 'Võ Sơn nam', '0965276269', '2021-07-06', '18:41', '2021-07-05 17:52:10', '0', '0', '1'),
(11, 'Võ Sơn nam', '0965276269', '2021-07-06', '18:41', '2021-07-05 17:52:41', '1', '0', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `phone` char(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`id`, `name`, `gender`, `phone`, `email`, `address`) VALUES
(1, 'Võ Sơn nam', 'M', '0965276269', 'vosonnam95@gmail.com', 'On the Moon');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `offdate`
--

DROP TABLE IF EXISTS `offdate`;
CREATE TABLE IF NOT EXISTS `offdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromdate` varchar(255) NOT NULL,
  `todate` varchar(255) NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `offdate`
--

INSERT INTO `offdate` (`id`, `fromdate`, `todate`, `status`) VALUES
(1, '2021-07-06 08:31', '2021-07-06 08:31', '1'),
(2, '2021-07-06 08:31', '2021-07-06 18:31', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `useemail` char(1) NOT NULL,
  `txtemail` text NOT NULL,
  `usesms` char(1) NOT NULL,
  `txtsms` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`username`, `password`, `useemail`, `txtemail`, `usesms`, `txtsms`) VALUES
('admin', 'admin@123', '1', 'Nam ngáo đá', '1', 'hi gay');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
