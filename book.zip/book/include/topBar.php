<div class="top-bar d-none d-md-block">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="top-bar-left">
                    <div class="text">
                        <h2>8:00 - 17:00</h2>
                        <p>MỞ CỦA TỪ THỨ 2 ĐẾN THỨ 6</p>
                    </div>
                    <div class="text">
                        <h2>+8493 324 5772</h2>
                        <p>GỌI ĐỂ ĐẶT LỊCH</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="top-bar-right">
                    <div class="social">
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/luuba.on.0311" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                        <a href=""><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>