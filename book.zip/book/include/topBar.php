<div class="top-bar d-none d-md-block">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="top-bar-left">
                    <div class="text">
                        <h2>7:00 - 18:00</h2>
                        <p>MỞ CỬA CÁC NGÀY TRONG TUẦN</p>
                    </div>
                    <div class="text">
                        <h2>(84).28.38400532</h2>
                        <p>GỌI ĐỂ ĐẶT LỊCH</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="top-bar-right">
                    <div class="social">
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/groups/488066407910478" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                        <a href=""><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>