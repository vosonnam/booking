<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-contact">
                            <h2>Địa Chỉ</h2>
                            <p><i class="fa fa-map-marker-alt"></i>
                                Số 2, Đường Trường Sa, Phường 17, Quận Bình Thạnh, Thành phố Hồ Chí Minh.
                            </p>
                            <p><i class="fa fa-phone-alt"></i>+8493 324 5772</p>
                            <p><i class="fa fa-envelope"></i>keymudo8@gmail.com</p>
                            <div class="footer-social">
                                <a href=""><i class="fab fa-twitter"></i></a>
                                <a href="https://www.facebook.com/luuba.on.0311" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href=""><i class="fab fa-youtube"></i></a>
                                <a href=""><i class="fab fa-instagram"></i></a>
                                <a href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                
            </div>
        </div>
    </div>
    <div class="container copyright">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; <a href="#"></a> All Right Reserved.</p>
            </div>
            <div class="col-md-6">
                <p><a href="https://www.facebook.com/luuba.on.0311" target="_blank">Designed By Lưu Bá Ôn</a></p>
            </div>
        </div>
    </div>
</div>