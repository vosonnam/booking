function queryDataPostJSon(url,dataSend,callback){
    $.ajax({
        type: 'POST',
        url: url,
        data: dataSend,
        async: true,
        dataType: 'JSON',
        success: callback
    });
}
$('form').submit(function(e){
	e.preventDefault();
	var dataSend=$('form').serialize();
	dataSend+='&event=booking';
	queryDataPostJSon("API/user/add.php",dataSend,function (res) {
		if(res['booking']==1){
			alert(res['msg']);
            window.location.href ='booking.php';
		}else{
			alert(res['msg']);
		}
	});
});