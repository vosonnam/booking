<?php
require_once("../server.php");
require("SpeedSMSAPI.php");
require("TwoFactorAPI.php");
function getUserInfo() {
    $sms = new SpeedSMSAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $userInfo = $sms->getUserInfo();
    var_dump($userInfo);
}

function sendSMS($phone, $content) {
    $sms = new SpeedSMSAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $return = $sms->sendSMS([$phone], $content, SpeedSMSAPI::SMS_TYPE_CSKH, "4cad17254f7c8de7");
    var_dump($return);
    return ($return['status']==='success')?1:0;
}

//$content contain OTP conde only
function sendVoiceOTP($phone, $content) {
    $sms = new SpeedSMSAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $return = $sms->sendVoice($phone, $content);
    var_dump($return);
}

function createPIN($phone, $content, $appId) {
    $twoFA = new TwoFactorAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $result = $twoFA->pinCreate($phone, $content, $appId);
    var_dump($result);

}

function verifyPIN($phone, $pinCode, $appId) {
    $twoFA = new TwoFactorAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $result = $twoFA->pinVerify($phone, $pinCode, $appId);
    var_dump($result);
}

function sendMMS($phone, $content, $link) {
    $sms = new SpeedSMSAPI("HVbE2h7xbdBd8PA3FKyRSkf0K-meweF9");
    $return = $sms->sendMMS([$phone], $content, $link, "4cad17254f7c8de7");
    var_dump($return);
}

function getAPI($key) {
    return isset($_GET[$key])? $_GET[$key]:"";
}
function postAPI($key) {
    return isset($_POST[$key])? $_POST[$key]:"";
}
$event=postAPI("event");
// $event=getAPI("event");
switch ($event) {
    case '0':
        getUserInfo();
        break;
    case '1':
        $id=postAPI('id');
        // $id=getAPI('id');
        $sql=mysqli_query($conn,"SELECT user.txtsms, book.phone FROM user JOIN book ON book.id='$id' AND book.status=1 AND book.fbsms=0 AND user.usesms=1");
        $row=mysqli_fetch_array($sql);
        $phone=$row['phone'];
        $sms=$row['txtsms'];
        if($row>0){
            if(sendSMS($phone,$sms)){
                mysqli_query($conn,"UPDATE `book` SET `fbsms`='1' WHERE `id`='$id'");
                $jsonData['status']=1;
            }else{
                $jsonData['status']=0;
                $jsonData['msg']="SMS nhắc hẹn gửi không thành công";
            }
        }else{
            $jsonData['status']=0;
            $jsonData['msg']="Điều kiện gửi không thoả";
        }
        echo json_encode($jsonData);
        // sendSMS($phone,$sms);
        break;
    
    default:
        echo "Chọn thao tác để thực hiện";
        break;
}
mysqli_close($conn);
?>
<!-- C:\wamp\www\booking\API\SMS\index.php:14:
array (size=3)
  'status' => string 'success' (length=7)
  'code' => string '00' (length=2)
  'data' => 
    array (size=5)
      'tranId' => float 4850399541
      'name' => string 'API' (length=3)
      'totalSMS' => int 1
      'totalPrice' => int 80
      'invalidPhone' => 
        array (size=0)
          empty -->