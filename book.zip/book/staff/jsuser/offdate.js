$('form').submit(function(e){
  e.preventDefault();
  var dataSend=$('form').serialize();
	dataSend+='&event=setoff';
	queryDataPostJSon("API/staff/add.php",dataSend);
});