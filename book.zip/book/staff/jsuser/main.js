function queryDataPostJSon(url,dataSend,callback){
    $.ajax({
        type: 'POST',
        url: url,
        data: dataSend,
        async: true,
        dataType: 'JSON',
        success: callback
    });
}
function queryDataGetJSon(url,dataSend,callback){
    $.ajax({
        type: 'GET',
        url: url,
        data: dataSend,
        async: true,
        dataType: 'JSON',
        success: callback
    });
}
function buildSlidePage(obj,codan,pageActive,totalPage) {
    var html="";
    pageActive=parseInt(pageActive);
    for(i = 1 ; i <=codan; i++) {
        if(pageActive-i<0) break;
        html='<button type="button" class="btn btn-outline btn-default" value="'+(pageActive-i)+'">'+(pageActive-i+1)+'</button>'+html;
    }
    if(pageActive>codan){
        html='<button type="button" class="btn btn-outline btn-default" value="'+(pageActive-i)+'">...</button>'+html;
    }
    html+='<button type="button" class="btn btn-outline btn-default" style="background-color: #5cb85c" value="'+pageActive+'">'+(pageActive+1)+'</button>';
    for(i = 1 ; i <=codan; i++){
        if(pageActive+i>=totalPage) break;
        html=html+'<button  type="button" class="btn btn-outline btn-default" value="'+(pageActive+i)+'">'+(pageActive+i+1)+'</button>';
    }
    if(totalPage-pageActive>codan+1){
        html=html+'<button type="button" value="'+(pageActive+i)+'" class="btn btn-outline btn-default">...</button>';
    }
    obj.html(html);
}
// queryDataPostJSon("API/user/get.php",{event:'smsuser'},function (res) {
//     var data=res['smsuser'];
//     $('#smsuser').data('id', data['id']);
//     $('#smsuser').data('bookdate', data['bookdate']);
//     // console.log(data['id']);
//     // console.log(data['bookdate']);
// });
// function test() {
//     var id=$('#smsuser').data('id');
//     console.log(id[0]);
//     var bookdate=$('#smsuser').data('bookdate');
//     console.log(bookdate[0]);
//     $('#smsuser').text('hi you');
// }
// test();
// function smsUser(){

//     var date = new Date().valueOf();
//     // var bookdate = (new Date("2021-07-06 18:35")).valueOf()-3600000;
//     var bookdate = (new Date("2021-07-06 20:10")).valueOf();
//     var arrPhone=["6", "7", "8", "9"];
//     if (date>=bookdate) {
//         for( i in  arrPhone){
//             var dataSend={event:1, 
//                     id: arrPhone[i]}
//             queryDataPostJSon("API/SMS/index.php",dataSend,function (res) {
//                 console.log(res['status']);
//             });
//         }
//         arrPhone=[];
//     }

// }
// setInterval(function(){

//     var date = new Date().valueOf();
//     // var bookdate = (new Date("2021-07-06 18:35")).valueOf()-3600000;
//     var bookdate = (new Date("2021-07-06 20:10")).valueOf();
//     var arrPhone=["6", "7", "8", "9"];
//     if (date>=bookdate) {
//         for( i in  arrPhone){
//             var dataSend={event:1, 
//                     id: arrPhone[i]}
//             queryDataPostJSon("API/SMS/index.php",dataSend,function (res) {
//                 console.log(res['status']);
//             });
//         }
//         arrPhone=[];
//     }

// },60000);
function logout() {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = "../index.php";
}
$('#dangxuat').click(function () {
    logout();
})
function checklogin() {
    var uname=localStorage.getItem("username");
    if(uname=="" || uname==undefined || uname==null){
        window.location.href = "../index.php";
    }
    $('.username').text(uname);
}
checklogin();