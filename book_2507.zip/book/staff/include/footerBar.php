<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-contact">
                            <h2>Địa Chỉ</h2>
                            <p><i class="fa fa-map-marker-alt"></i>
                                Số 2, Đường Trường Sa, Phường 17, Quận Bình Thạnh, Thành phố Hồ Chí Minh.
                            </p>
                            <p><i class="fa fa-phone-alt"></i>(84).28.38400532</p>
                            <p><i class="fa fa-envelope"></i>phanhieu@tlu.edu.vn</p>
                            <div class="footer-social">
                                <a href=""><i class="fab fa-twitter"></i></a>
                                <a href="https://www.facebook.com/groups/488066407910478" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href=""><i class="fab fa-youtube"></i></a>
                                <a href=""><i class="fab fa-instagram"></i></a>
                                <a href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                
            </div>
        </div>
    </div>
    <div class="container copyright" >
        <div class="row">
            <div class="col-md-12">
                <p style="text-align:center">&copy; <a href="#"></a> All Right Reserved.</p>
            </div>
            <div class="col-md-12" >
                <p style="text-align:center"><a href="https://www.facebook.com/groups/488066407910478" target="_blank">Designed By Nhóm 2</a></p>
            </div>
            <div class="col-md-12">
                <p style="text-align:center"><a href="#" target="_blank">Võ Sơn Nam</a></p>
                <p style="text-align:center"><a href="#" target="_blank">Đinh Hưu Hiếu</a></p>
                <p style="text-align:center"><a href="#" target="_blank">Đinh Xuân Quân</a></p>
                <p style="text-align:center"><a href="#" target="_blank">Võ Nguyễn Xuân Quỳnh</a></p>
                <p style="text-align:center"><a href="#" target="_blank">Lưu Bá Ôn</a></p>
            </div>
        </div>
    </div>
</div>